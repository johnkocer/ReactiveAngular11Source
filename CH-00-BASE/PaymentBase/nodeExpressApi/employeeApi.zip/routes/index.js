var express = require('express');
var router = express.Router();

const { v4: uuidv4 } = require('uuid');
//const uuid = require('node-uuid');

const low = require('lowdb')
const FileSync = require('lowdb/adapters/FileSync');
const { json } = require('express');
 
const adapter = new FileSync('db.json')
const db = low(adapter)

db.defaults({ employees: [], user: {} })
  .write()

/* GET home page. */
// router.get('/', function(req, res, next) {
//   res.render('index', { title: 'Express' });
// });

router.get('/api/employees', (req, res, next) => {
  let resData= db.get('employees').value();
  console.log("[Employees - GET ALL]", resData.length)
  console.table( resData.slice(0,5))
  res.status(200).json(resData);
});

router.post('/api/employees', (req, res, next) => {
  let data = req.body;
  data.id = uuidv4();
  let item = db.get('employees').push(data).last().value();
  console.log("[Employees - POST]",  item)
  res.status(200).json(item);
});

router.get('/api/employees/:id', (req, res, next) => {
  //res.status(200);
  let id = req.params.id;
  let item = db.get('employees').find({id}).value();
  console.log("[Employees - GET  ] Item: ", item)
  //db.get('employees').remove({id}).value();
  res.status(200).json(item);
});

router.get('/api/employees/GetEmployeeByName/:name', (req, res, next) => {
  //res.status(200);
  let name = req.params.name;
  let list = db.get('employees').filter(s => s.name.includes(name)).value();
  console.log("[Employees - GET  ] Record Count: ", list.length)
  //db.get('employees').remove({id}).value();
  console.table( list.slice(0,5))

  res.status(200).json(list);
});


router.put('/api/employees/:id', (req, res, next) => {
  let id = req.params.id;
  let item = db.get('employees').find({id}).assign(req.body).value();
  console.log("[Employees - PUT] ", item)
  
  res.status(200).json(item);
});

router.delete('/api/employees/:id', (req, res, next) => {
  let id = req.params.id;
  let item = db.get('employees').find({id}).value();
  db.get('employees').remove({id}).value();
  console.log("[Employees - DELETE]", item)

  res.status(200).json(item);
});

module.exports = router;
